<script>
    let correct = 0;
    let Incorrect = 0;
    export let choosen_optn;
    export let Question;
    //export let attempted;
    //{choosen_optn} {Question} {attempted}

    for (let i = 0; i < choosen_optn.length; i++) {
        if (choosen_optn[i]["isCorrect"] == true) {
            correct++;
        } else if (choosen_optn[i]["isCorrect"] == false) {
            Incorrect++;
        }
    }
</script>

<style>
    .inblock {
        display: inline-block;
    }
    .index_data {
        background-color: darkgrey;
        border-radius: 50%;
        width: 30px;
        height: 30px;
        line-height: 30px;
        text-align: center;
        margin-bottom: 5px;
    }

    .label_correct,
    .label_incorrect {
        height: 30px;
        line-height: 30px;
        width: 150px;
        text-align: center;
        color: #fff;
        margin-left: 5px;
        border-radius: 5px;
    }

    .label_correct {
        background-color: green;
    }
    .label_incorrect {
        background-color: red;
    }

    .snippet_data {
        width: 800px;
    }
</style>

<h1>Result</h1>
<button
    style="background:lightgray; color:black;box-shadow:none; margine-left: 5px;">All
    :{Question.length}</button>
<button
    style="background:lightgray; color:black;box-shadow:none; margine-left: 5px;">Unattempted
    :
    {Question.length - (correct + Incorrect)}</button>
<button
    style="background:lightgray; color:black;box-shadow:none; margine-left: 5px;">correct
    :{correct}</button>
<button
    style="background:lightgray; color:black;box-shadow:none; margine-left: 5px;">Incorrect
    :{Incorrect}</button>

<hr />
<div>
    {#each Question as que_data, i (que_data)}
        <div>
            <div class="inblock index_data">{i + 1}</div>
            <div class="inblock snippet_data">{que_data.snippet}</div>
            <div class="inblock ans_label">
                <div class="{(choosen_optn[i] && choosen_optn[i]['isCorrect'] == true) ? 'label_correct' : 'label_incorrect'}">
                    {choosen_optn[i] == undefined ? 'Unattempted' : choosen_optn[i]['isCorrect'] ? (choosen_optn[i]['isCorrect'] == 'Unattempted' ? 'Unattempted' : 'Correct') : 'InCorrect'}
                </div>
            </div>
        </div>
    {/each}
</div>
