<script>
    import quis_js from "./QuestionStorage.js";
    import Modal from "./Modal.svelte";
    import Sidebar from "./Sidebar.svelte";
    import ResultPage from "./ResultPage.svelte";
    let attempted = 0;
    let sidebar_show = false;
    let showModal = false;
    let Question;
    let choosen_optn = [];
    let check_ans = "";
    let resultStatus = false;
    import { tweened } from "svelte/motion";
    let original = 10 * 60; // TYPE NUMBER OF SECONDS HERE
    let timer = tweened(original);

    setInterval(() => {
        if ($timer > 0) $timer--;
        if($timer == 0) {
            showModal = true;
        }
    }, 1000);

    $: minutes = Math.floor($timer / 60);
    $: minname = minutes > 1 ? "mins" : "min";
    $: seconds = Math.floor($timer - minutes * 60);

    // export let handleClick;
    const unsubscribe = quis_js.subscribe((itemsData) => {
        Question = itemsData;
    });

    let and_opt;
    let que_no = 0;
    let last = false;
    let first = true;

    // function choose_opt() {
    //     ans_opt++;
    // }

    

    function CheckAns(indx_no, id, option_data) {
        choosen_optn[indx_no] = {
            'id': id,
            'isCorrect': option_data == 1 ? true : false,
        };
        attempted = 0;
        for (
            let index_data = 0;
            index_data < choosen_optn.length;
            index_data += 1
        ) {
            if (typeof choosen_optn[index_data] == "undefined") {
                choosen_optn[index_data] = { 'id': "", 'isCorrect': "Unattempted" };
                // unattempted = choosen_optn.length - attemped ;
            } else {
                attempted += 1;
            }
        }
        console.log({ choosen_optn: choosen_optn });
    }

    function next() {
        que_no += 1;
        first = false;
        if (que_no == 10) {
            last = true;
        }
        check_ans = "";
    }

    function pre() {
        que_no -= 1;
        last = false;
        if (que_no < 1) {
            first = true;
        }
        check_ans = "";
    }

    function submitAns(ans) {
        console.log(check_ans);
        if (check_ans) {
            check_ans = "";
        } else {
            if (
                choosen_optn[ans] != undefined &&
                choosen_optn[ans]["isCorrect"] == true
            ) {
                check_ans = "Correct";
            } else {
                check_ans = "Incorrect";
            }
        }
    }
</script>

<style>
    footer {
        position: fixed;
        width: 100%;
        bottom: 0;
        left: 0;
        height: 3rem;
        background-color: #424958;
        display: flex;
        justify-content: flex-end;
        align-items: center;
        box-shadow: 0 2px 6px rgb(0, 0, 0, 0.26);
        padding-right: 60px;
    }

    footer div {
        margin-right: 8px;
        margin-top: 8px;
    }
    .showModal {
        margin-left: 5px;
    }

    .incorrect {
        color: #fff;
        background-color: salmon;
    }

    .correct {
        color: #fff;
        background-color: springgreen;
    }

    .incorrect,
    .correct {
        height: 50px;
        width: 150px;
        font-weight: 600;
        vertical-align: middle;
        line-height: 50px;
        border-radius: 5px;
    }

    .disabled {
        pointer-events: none;
    }
    .notdisabled {
        pointer-events: auto;
    }
</style>

<main>
    {#if !resultStatus}
    {#each Question as que, i (que)}
        {#if i == que_no}
            <h4>{JSON.parse(que.content_text).question}</h4>

            {#if check_ans}
                <center>
                    <div
                        class={check_ans == 'Correct' ? 'correct' : 'incorrect'}>
                        {check_ans}
                    </div>
                </center>
            {/if}
            <div class={check_ans ? 'disabled' : 'notdisabled'}>
                {#each JSON.parse(que.content_text).answers as ans_opt}
                    <label><input
                            type="radio"
                            name="options"
                            checked={choosen_optn[que_no] && choosen_optn[que_no].id == ans_opt.id ? true : false}
                            on:click={CheckAns.bind(this, que_no, ans_opt.id, ans_opt.is_correct)}
                            value={ans_opt.is_correct} />
                        {@html ans_opt.answer}</label>
                {/each}
            </div>
            {#if check_ans}
                <center>
                    <div>
                        {JSON.parse(que.content_text).explanation}
                    </div>
                </center>
            {/if}
            

        {/if}
    {/each}
    <footer>
        <div>
        <slot name="footer">
            <button style="margin-right: 5px;">{minutes} : {seconds}</button>
            <button
                on:click={() => (sidebar_show = !sidebar_show)}
                style="margin-right: 5px;">List Item</button>
            <Sidebar bind:show={sidebar_show} />
            <button
                style="margin-right: 5px;"
                on:click={submitAns.bind(this, que_no)}>{check_ans ? 'Retry' : 'Submit'}</button>
            <button on:click={pre} disabled={first}>Previous</button>
            <button
                style="background:none; color:white;box-shadow:none;">{que_no + 1}
                of 11</button>
            <button on:click={next} disabled={last}>Next</button>
        </slot>
        <button class="showModal" on:click={() => (showModal = true)}>End Test</button>
    </div>
        {#if showModal}
            <Modal
                {attempted}
                {Question}
                on:cancel={() => (showModal = false)}
                on:close={() => (resultStatus = true)}>
                <h1 slot="header">Hello !</h1>
                <p>Opening and closing modal</p>
                <!-- <button slot="footer" on:close="{() => showModal = 'false'}">Confirm</button>  -->
            </Modal>
        {/if}
    </footer>
    {:else}
    <ResultPage {choosen_optn} {Question} {attempted}/>
    {/if}
</main>
